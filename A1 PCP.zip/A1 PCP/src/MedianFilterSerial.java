import java.io.*;
import java.util.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class MedianFilterSerial{

    // Instance variables 
    BufferedImage img = null;
    int[][] rgbArray;
    int[][] filterPixels;
    int height , width, filter;
    String output;


    public MedianFilterSerial ( String input, String output , int filter ){

        try {

            File file = new File(input);
            img = ImageIO.read(file);
        } catch (IOException e) {
            
            e.printStackTrace();
        }
        this.output = output;
        this.height = img.getHeight();
        this.width = img.getWidth();
        rgbArray = new int[height][width];
        setPixels();
        this.filter = filter;
        this.filterPixels = new int[height][width];
        
    }

    /**
     * 
     * @return int[][]
     */
    private void setPixels(){
        for (int row = 0; row < height;row++){
            for (int col = 0; col < width;col++){
                rgbArray[row][col]= img.getRGB(col, row);
            }
        }
    }

    public void medianFilter(){

        
        //
        int rad = (filter)/2; //radius of the filter
        
        // individual arrays for the pixels
        int[] r = new int[ filter * filter];
        int[] g = new int[ filter * filter];
        int[] b = new int[ filter * filter];


        for ( int row = 0; row <  height; row++){
            for ( int col = 0; col < width ; col++){

                int i = 0;
                for ( int y = row - rad; y < row - rad + filter; y++){
                    for ( int x = col -rad; x < col - rad + filter; x++) {

                        if ( x < 0 || y < 0 || x >= width || y >= height ){
                            r[i] = 0;
                            g[i] = 0;
                            b[i] = 0;
                        }
                        else {
                            int pixel = rgbArray[y][x];

                            r[i] = (pixel>>16) & 0xff;
                            g[i] = (pixel>>8) & 0xff;
                            b[i] = (pixel) & 0xff;
                            
                        }
                        i++;
                    }
                }
                // sorting the arrays 
                Arrays.sort(r);
                Arrays.sort(g);
                Arrays.sort(b);

                // the medians of each color 
                int red = r[(filter * filter) /2];
                int green = g[(filter * filter) /2];
                int blue = b[(filter * filter) /2];

                int rgb = (red<<16) | (green<<8) | blue;
                filterPixels[row][col] = rgb;

                
            }
        }
    }

    public void writeToImage (){

        BufferedImage out = new BufferedImage( width, height, BufferedImage.TYPE_INT_RGB);
        for ( int row = 0; row < height; row++){
            for ( int col = 0; col < width; col++) {
                int rgb = filterPixels[row][col];

                out.setRGB(col, row, rgb);
                
            }
        }

        try {
            ImageIO.write(out, "jpeg", new File(output));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }



    public static void main(String[] args){
        MedianFilterSerial  medianFilter = new MedianFilterSerial(args[0], args[1], Integer.parseInt(args[2]));
        long startTime = System.nanoTime();

        medianFilter.medianFilter();
        medianFilter.writeToImage();
        long endTime = System.nanoTime();
        long duration = (endTime - startTime)/1000000;
        System.out.println("Time duration for Serial median filter is " + duration + " milliseconds");
    }


    
}
