import java.util.*;
import java.util.concurrent.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;

public class MeanFilterParallel {
    static class MeanFilter extends RecursiveTask<Integer[][]>{
        // Instance variables 
        private BufferedImage img = null;
        private int[][] rgbArray;
        private int THRESHOLD = 1000;
        private int filter, x_low, x_high, y_low, y_high;
        private boolean divide; // dividing the length of an array
        

        public MeanFilter(int[][] rgbArray, int filter, int x_low, int y_low, int x_high, int y_high, boolean divide){
            this.rgbArray = rgbArray;
            this.filter = filter;
            this.x_low = x_low;
            this.y_low = y_low;
            this.x_high = x_high;
            this.y_high = y_high;
            this.divide = divide;
        }

        private Integer[][] meanFilter(){
            int yIndex = 0;
            int w = x_high - x_low;
            int h = y_high - y_low;
            int width = rgbArray[0].length;
            int height = rgbArray.length;
            int radius = (filter - 1) / 2;
            Integer[][] pixels = new Integer[h][w];
            
            for (int y = y_low; y < y_high; y++) {
                int xIndex = 0;
                for (int x = x_low; x < x_high; x++) {

                    int xStart = x - radius;
                    int yStart = y - radius;

                    int red = 0;
                    int green = 0;
                    int blue = 0;
                    int alpha = 0;

                    for (int n = xStart; n < xStart + filter; n++) {
                        for (int m = yStart; m < yStart + filter; m++) {

                            if (!(n < 0 || n >= width || m < 0 || m >= height)) {

                                int pixel = rgbArray[m][n];

                                red += ((pixel >> 16) & 0xff);
                                green += ((pixel >> 8) & 0xff);
                                blue += (pixel & 0xff);
                                alpha += ((pixel >> 24) & 0xff);

                            }

                            else {
                                red += 0;
                                green += 0;
                                blue += 0;
                                alpha += 0;
                            }
                        }
                    }       
 
                    // the medians of each color 
                    int r = red / (filter*filter);
                    int g = green/(filter * filter);
                    int b = blue/(filter * filter);

                    int rgb = (r<<16) | (g<<8) | b;
                    pixels[yStart][xStart] = rgb;

                }
                yIndex++;
            }

            return pixels;
        }


        private static Integer[][] combine(Integer[][] part1, Integer[][] part2, boolean divide) {

            if (divide) {

                Integer[][] combined = new Integer[part1.length][part1[0].length + part2[0].length];

                for (int i = 0; i < combined.length; i++) {
                    int index = 0;

                    for (int a : part1[i]) {
                        combined[i][index] = a;
                        index++;
                    }

                    for (int b : part2[i]) {
                        combined[i][index] = b;
                        index++;
                    }
                }

                return combined;
            } else {
                int h = part1.length + part2.length;
                Integer[][] combined = new Integer[h][part1.length];

                int index = 0;

                for (Integer[] a : part1) {
                    combined[index] = a;
                    index++;
                }

                for (Integer[] b : part2) {
                    combined[index] = b;
                    index++;
                }

                return combined;

            }

        }


        @Override
        protected Integer[][] compute() {
            if ((x_high - x_low) * (y_high - y_low) <= THRESHOLD) {

                return meanFilter();
            } 
            else {
                if (divide) {
                    int middle = x_low + (x_high - x_low) / 2;
                    MeanFilter left = new MeanFilter(rgbArray, filter, x_low, y_low, middle, y_high, !divide);
                    MeanFilter right = new MeanFilter(rgbArray, filter, middle, y_low, x_high, y_high, !divide);
                    left.fork();                       
                    Integer[][] rightSide = right.compute();
                    Integer[][] leftSide = left.join();

                    return combine(leftSide, rightSide, divide);

                } 
                else {
                    int middle = y_low + (y_high - y_low) / 2;
                    MeanFilter top = new MeanFilter(rgbArray, filter, x_low, y_low, x_high, middle, !divide);
                    MeanFilter bottom = new MeanFilter(rgbArray, filter, x_low, middle, x_high, y_high, !divide);
                    top.fork();
                    Integer[][] rightSide = bottom.compute();
                    Integer[][] leftSide = top.join();

                    return combine(leftSide, rightSide, divide);
                    
                }
            }
        }
    }
   
    public static void main(String args[]) throws IOException {

        BufferedImage img = ImageIO.read(new File(args[0]));
        int imgWidth = img.getWidth();
        int imgHeight = img.getHeight();
        int[][] rgbArray = new int[imgHeight][imgWidth];

        for (int h = 0; h < imgHeight; h++) {
            for (int w = 0; w < imgWidth; w++) {
                rgbArray[h][w] = img.getRGB(w, h);
            }
        }

        MeanFilter meanFilter = new MeanFilter(rgbArray, Integer.parseInt(args[2]), 0, 0, imgWidth, imgHeight, true);
        long startTime = System.nanoTime();
        int numThreads = Runtime.getRuntime().availableProcessors();
        ForkJoinPool forkJoinPool = new ForkJoinPool(numThreads);

        Integer[][] pixels = forkJoinPool.invoke(meanFilter);

        File output = new File(args[1]);
        BufferedImage outputImage = new BufferedImage(imgWidth, imgHeight, BufferedImage.TYPE_INT_RGB);

        for (int x = 0; x < imgWidth; x++) {
            for (int y = 0; y < imgHeight; y++) {
                int rgb = pixels[y][x];
                outputImage.setRGB(x, y, rgb);
            }
        }
        long endTime = System.nanoTime();
        long duration = (endTime - startTime)/1000000;
        System.out.println("Time duration for Parallel mean filter is " + duration + " milliseconds");

        ImageIO.write(outputImage, "jpeg", output);

    }

    

    
    
} 